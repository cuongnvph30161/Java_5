package com.example.dethithu1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dethithu1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
