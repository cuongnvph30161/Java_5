package com.example.dethithu1.controller;

import com.example.dethithu1.entity.KhachHang;
import com.example.dethithu1.entity.PhieuGiamGia;
import com.example.dethithu1.service.KhachHangService;
import com.example.dethithu1.service.PhieuGiamGiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class PhieuGiamGiaController {
    @Autowired
    private PhieuGiamGiaService phieuGiamGiaService;
    @Autowired
    private KhachHangService khachHangService;
    private List<KhachHang> listKhachHang;
    private PhieuGiamGia thePhieuGiamGia;

    @GetMapping("/phieu-giam-gia/hien-thi")
    public String listPhieuGiamGia(Model model) {
        List<PhieuGiamGia> listPhieuMaGiam = phieuGiamGiaService.getAll();
        model.addAttribute("phieuMaGiams", listPhieuMaGiam);
        return "index";
    }

    @GetMapping("/phieu-giam-gia/delete")
    public String deletePhieuGiamGiaById(@RequestParam("id") String id) {
        phieuGiamGiaService.deleteById(id);
        return "redirect:/phieu-giam-gia/hien-thi";
    }

    @GetMapping("/phieu-giam-gia/update")
    public String detailPhieuGiamGia(@RequestParam("id") String id, Model model) {

        thePhieuGiamGia = phieuGiamGiaService.finById(id);
        System.out.println("logggggggggggg"+" "+thePhieuGiamGia);
        model.addAttribute("PhieuGiamGia", thePhieuGiamGia);

        listKhachHang = khachHangService.getAll();
        model.addAttribute("listMaKhachHang", listKhachHang);
        return "update";
    }

    @PostMapping("/phieu-giam-gia/add")
    public String addPhieuGiamGia(@ModelAttribute("phieuGiamGia") PhieuGiamGia phieuGiamGia, Model model) {


        if (phieuGiamGia.getTenPhieu().equals("") ||phieuGiamGia.getTenPhieu().trim().isEmpty()) {
            model.addAttribute("errorTenPhieu", "Không được rỗng");
            model.addAttribute("PhieuGiamGia",phieuGiamGia );
            model.addAttribute("listMaKhachHang", listKhachHang);
            return "forward:/phieu-giam-gia/update";
        }

        phieuGiamGiaService.save(phieuGiamGia);
        return "redirect:/phieu-giam-gia/hien-thi";


    }

}
