package com.example.dethithu1.repository;

import com.example.dethithu1.entity.KhachHang;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface KhachHangRepository extends JpaRepository<KhachHang,Integer> {
    @Query(value = "select TenKhachHang from KhachHang where MaKhachHang=?",nativeQuery = true)
    String getTenKhachHangByMaKhachHang(String maKhachHang);
}
