package com.example.dethithu1.service;

import com.example.dethithu1.entity.KhachHang;

import java.util.List;

public interface KhachHangService {
   List<KhachHang> getAll();
}
