package com.datn.dongho5s.Cache;

import java.util.HashMap;

public class DiaChiCache {
    public static HashMap<Integer,String> hashMapTinhThanh = new HashMap<>();
    public static HashMap<Integer,HashMap<Integer,String>> hashMapQuanHuyen = new HashMap<>();
    public static HashMap<Integer,HashMap<String,String>> hashMapPhuongXa = new HashMap<>();

}
