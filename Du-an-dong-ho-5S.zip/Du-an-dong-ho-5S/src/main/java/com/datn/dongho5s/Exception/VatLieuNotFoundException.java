package com.datn.dongho5s.Exception;

public class VatLieuNotFoundException extends Exception{
    public VatLieuNotFoundException(String message){
        super(message);
    }
}
