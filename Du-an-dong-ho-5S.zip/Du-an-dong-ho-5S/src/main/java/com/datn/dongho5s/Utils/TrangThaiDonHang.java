package com.datn.dongho5s.Utils;

public class TrangThaiDonHang {
    public static final Integer CHO_XAC_NHAN = 0;
    public static final Integer DANG_CHUAN_BI = 1;
    public static final Integer DANG_GIAO = 2;
    public static final Integer HOAN_THANH = 3;
    public static final Integer DA_HUY = 4;
    public static final Integer YEU_CAU_HOAN_TRA = 5;
    public static final Integer DA_HOAN_TRA = 6;

}
