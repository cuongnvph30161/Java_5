package com.datn.dongho5s.Exception;

public class SanPhamNotFountException extends Exception{
    public SanPhamNotFountException(String massage){
        super(massage);
    }
}
