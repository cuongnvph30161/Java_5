package com.datn.dongho5s.Exception;

public class NhanVienNotFoundException extends Exception {
    public NhanVienNotFoundException(String massage){
        super(massage);

    }
}
