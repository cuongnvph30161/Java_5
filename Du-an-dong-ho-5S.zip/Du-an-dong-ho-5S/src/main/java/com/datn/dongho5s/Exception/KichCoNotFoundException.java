package com.datn.dongho5s.Exception;

public class KichCoNotFoundException extends Exception{
    public KichCoNotFoundException(String message){
        super(message);
    }
}
