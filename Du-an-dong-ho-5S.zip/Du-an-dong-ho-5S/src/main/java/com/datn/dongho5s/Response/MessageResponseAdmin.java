package com.datn.dongho5s.Response;

public class MessageResponseAdmin {
    private String message;

    public MessageResponseAdmin(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
