package com.datn.dongho5s.Service;

import com.datn.dongho5s.Entity.AnhSanPham;

public interface AnhSanPhamService {
    AnhSanPham save(AnhSanPham anhSanPham);
}
