package com.datn.dongho5s.Exception;

public class DanhMucNotFoundException extends Exception{
    public DanhMucNotFoundException(String massage){
        super(massage);

    }
}
