package com.datn.dongho5s.Utils;

public class TrangThaiImei {
    public static final Integer LOI = 0;
    public static final Integer CHUA_BAN = 1;
    public static final Integer DANG_GIAO = 2;
    public static final Integer DA_BAN = 3;

}
