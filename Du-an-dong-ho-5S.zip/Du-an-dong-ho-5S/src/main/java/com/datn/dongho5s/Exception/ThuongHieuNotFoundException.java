package com.datn.dongho5s.Exception;

public class ThuongHieuNotFoundException extends Exception{
    public ThuongHieuNotFoundException(String massage){
        super(massage);
    }
}
