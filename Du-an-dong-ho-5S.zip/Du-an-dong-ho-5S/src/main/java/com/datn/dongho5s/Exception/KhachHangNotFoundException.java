package com.datn.dongho5s.Exception;

public class KhachHangNotFoundException extends Exception{
    public KhachHangNotFoundException(String message){
        super(message);
    }
}
