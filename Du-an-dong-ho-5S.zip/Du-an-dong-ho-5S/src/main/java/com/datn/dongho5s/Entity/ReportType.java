package com.datn.dongho5s.Entity;

public enum ReportType {
	DAY, MONTH, CATEGORY, PRODUCT, ORDERDETAIL
}
