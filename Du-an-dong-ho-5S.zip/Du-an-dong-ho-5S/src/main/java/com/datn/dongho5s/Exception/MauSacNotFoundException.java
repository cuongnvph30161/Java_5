package com.datn.dongho5s.Exception;

public class MauSacNotFoundException extends Exception{
    public MauSacNotFoundException(String massage){
        super(massage);
    }
}