package com.datn.dongho5s.Utils;

public class PhuongThucThanhToan {

    public static final Integer TRA_SAU = 0;
    public static final Integer VNPAY = 1;
}
