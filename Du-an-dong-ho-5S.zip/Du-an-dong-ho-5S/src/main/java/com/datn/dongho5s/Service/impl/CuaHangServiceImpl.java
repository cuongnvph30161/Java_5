package com.datn.dongho5s.Service.impl;


import com.datn.dongho5s.Service.CuaHangService;
import org.springframework.stereotype.Service;

@Service
public class CuaHangServiceImpl implements CuaHangService {
}
