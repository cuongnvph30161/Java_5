package com.datn.dongho5s.Exception;

public class KhuyenMaiNotFoundException extends Exception{
    public KhuyenMaiNotFoundException (String message){
        super(message);
    }
}
