package com.datn.dongho5s.Exception.CustomException;

public class DanhMucNotFoundException extends Exception {
    public DanhMucNotFoundException(String message){
        super(message);
    }
}
