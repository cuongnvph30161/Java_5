package com.datn.dongho5s.Exception;

public class CategoriesNotFoundException extends Exception{
    public CategoriesNotFoundException(String message){
        super(message);
    }
}
