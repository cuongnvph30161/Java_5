package com.datn.dongho5s.Exception;

public class ChiTietSanPhamNotFountException extends Exception{
    public  ChiTietSanPhamNotFountException (String massage){
        super(massage);
    }
}
