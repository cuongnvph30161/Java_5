package com.datn.dongho5s.Exception;

public class DayDeoNotFoundException extends Exception{
    public DayDeoNotFoundException (String massage){
        super(massage);
    }
}
