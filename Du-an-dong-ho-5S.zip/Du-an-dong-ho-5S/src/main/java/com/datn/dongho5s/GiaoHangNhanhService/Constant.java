package com.datn.dongho5s.GiaoHangNhanhService;

public class Constant {
    public static final String TOKEN = "14c14a31-1dbd-11ee-8bfa-8a2dda8ec551";

    public static final String ID_SHOP = "125042";
    public static final String CONTENT_TYPE = "application/json";
    public static final String REQUIRED_NOTE = "CHOXEMHANGKHONGTHU";
    public static final Integer DO_DAI_CANH_HOP_HANG = 20;
    public static final Integer TRONG_LUONG_SAN_PHAM = 200;
}
